#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#define PI 3.14159
int main()
{
	double r,h,volume,surface;
	printf("Input r and h;");
	scanf("%lf%lf",&r,&h);
	volume =1.0/3.0*PI*pow(r,2)*h;
	surface = PI*r*(r+sqrt(pow(r,2)+pow(h,2)));
	printf("----------------------------------\n");
	printf("volume = %f\n",volume);
	printf("surface = %f\n",surface);
    system("pause");
	return 0;
}