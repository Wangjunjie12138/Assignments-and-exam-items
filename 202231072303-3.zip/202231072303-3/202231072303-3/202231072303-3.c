#include<stdio.h>
#include<stdlib.h>
int main()
{
	int foot,inch;
	double height;
    printf("Input foot and inch;");
	scanf("%d%d",&foot,&inch);
	height= 0.3048 * (foot + inch/12.0);
	printf("-----------------------------\n");
	printf("height=%d feet %d inches = %f meters\n",foot,inch,height);
    system("pause");
	return 0;
}