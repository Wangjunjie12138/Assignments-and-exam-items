#include<stdio.h>
#include<stdlib.h>
int main()
{
	int num1,num2,sum,sub,mul,div;
	printf("input numl:");
	scanf("%d",&num1);
	printf("input num2:");
	scanf("%d",&num2);
	sum = num1 + num2;
	sub = num1 - num2;
	mul = num1 * num2;
	div = num1 / num2;
	printf("--------------------------------\n");
	printf("sum = num1 + num2 = %d + %d = %d\n",num1,num2,sum);
	printf("sub = num1 - num2 = %d - %d = %d\n",num1,num2,sub);
	printf("mul = num1 * num2 = %d * %d = %d\n",num1,num2,mul);
	printf("div = num1 / num2 = %d / %d = %d\n",num1,num2,div);
	system("pause");
	return 0;
}
