#include<stdio.h>
#include<stdlib.h>
int main()
{
	int a,b,c;
	printf("input a=");
	scanf("%d",&a);
	printf("\ninput b=");
	scanf("%d",&b);
	c=a/10*1000+b/10*100+a%10*10+b%10;
	printf("\nc=%d\n",c);
	system("pause");
	return 0;
}